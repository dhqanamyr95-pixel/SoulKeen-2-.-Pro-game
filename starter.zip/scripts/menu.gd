extends Control

signal map_chosen(map_id: String)

const Maps = preload("res://scripts/maps.gd")


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)

    var bg := ColorRect.new()
    bg.color = Color(0.07, 0.06, 0.05)
    add_child(bg)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)

    var margin := MarginContainer.new()
    add_child(margin)
    margin.set_anchors_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 56)
    margin.add_theme_constant_override("margin_right", 56)
    margin.add_theme_constant_override("margin_top", 36)
    margin.add_theme_constant_override("margin_bottom", 36)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    margin.add_child(box)

    var title := Label.new()
    title.text = "SOULKEEN: YEAR ZERO"
    title.add_theme_font_size_override("font_size", 54)
    title.add_theme_color_override("font_color", Color(0.95, 0.75, 0.35))
    box.add_child(title)

    var sub := Label.new()
    sub.text = "Choose your world"
    sub.add_theme_font_size_override("font_size", 24)
    sub.add_theme_color_override("font_color", Color(0.8, 0.78, 0.72))
    box.add_child(sub)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    box.add_child(scroll)

    var grid := GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 16)
    grid.add_theme_constant_override("v_separation", 16)
    scroll.add_child(grid)

    for m in Maps.all():
        var btn := Button.new()
        btn.text = "%s\n%s" % [m["name"], m["desc"]]
        btn.custom_minimum_size = Vector2(0, 120)
        btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        btn.add_theme_font_size_override("font_size", 22)
        btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        _style(btn)
        btn.pressed.connect(_on_pick.bind(String(m["id"])))
        grid.add_child(btn)


func _style(btn: Button) -> void:
    var normal := _box(Color(0.16, 0.13, 0.10), Color(0.55, 0.42, 0.22))
    var hover := _box(Color(0.22, 0.17, 0.12), Color(0.95, 0.75, 0.35))
    var pressed := _box(Color(0.30, 0.22, 0.12), Color(1.0, 0.85, 0.45))
    btn.add_theme_stylebox_override("normal", normal)
    btn.add_theme_stylebox_override("hover", hover)
    btn.add_theme_stylebox_override("pressed", pressed)
    btn.add_theme_stylebox_override("focus", normal)
    btn.add_theme_color_override("font_color", Color(0.95, 0.9, 0.8))


func _box(fill: Color, border: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = fill
    s.border_color = border
    s.set_border_width_all(3)
    s.set_corner_radius_all(14)
    s.content_margin_left = 18
    s.content_margin_right = 18
    s.content_margin_top = 12
    s.content_margin_bottom = 12
    return s


func _on_pick(id: String) -> void:
    map_chosen.emit(id)
