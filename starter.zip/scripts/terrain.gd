extends Node3D

const SIZE := 400.0
const SEGS := 160

var noise := FastNoiseLite.new()
var color_noise := FastNoiseLite.new()
var p: Dictionary = {}
var plateau_h := 1.8


func configure(params: Dictionary) -> void:
    p = params
    noise.seed = int(p["seed"])
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.frequency = float(p["freq"])
    noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    noise.fractal_octaves = 5
    noise.fractal_gain = 0.5
    color_noise.seed = int(p["seed"]) + 99
    color_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    color_noise.frequency = 0.08


func height_at(x: float, z: float) -> float:
    var half := SIZE * 0.5
    var d := Vector2(x, z).length()
    var r := d / half
    var base := float(p["base"])
    var h := noise.get_noise_2d(x, z) * float(p["amp"]) + base
    h -= smoothstep(0.55, 0.98, r) * (base + 16.0)
    var t := smoothstep(16.0, 34.0, d)
    return lerpf(plateau_h, h, t)


func build(params: Dictionary) -> void:
    configure(params)
    var n := SEGS + 1
    var half := SIZE * 0.5
    var step := SIZE / float(SEGS)

    var hs := PackedFloat32Array()
    hs.resize(n * n)
    for j in n:
        for i in n:
            hs[j * n + i] = height_at(-half + i * step, -half + j * step)

    var sand: Color = p["sand"]
    var grass: Color = p["grass"]
    var grass2: Color = p["grass2"]
    var rock: Color = p["rock"]

    var verts := PackedVector3Array()
    var norms := PackedVector3Array()
    var cols := PackedColorArray()
    var uvs := PackedVector2Array()
    var idx := PackedInt32Array()

    for j in n:
        for i in n:
            var x := -half + i * step
            var z := -half + j * step
            var h := hs[j * n + i]
            verts.append(Vector3(x, h, z))
            var hl := hs[j * n + maxi(i - 1, 0)]
            var hr := hs[j * n + mini(i + 1, n - 1)]
            var hd := hs[maxi(j - 1, 0) * n + i]
            var hu := hs[mini(j + 1, n - 1) * n + i]
            var nrm := Vector3(hl - hr, 2.0 * step, hd - hu).normalized()
            norms.append(nrm)
            uvs.append(Vector2(float(i), float(j)) * 0.2)
            var v := 0.5 + 0.5 * color_noise.get_noise_2d(x, z)
            var col := grass.lerp(grass2, v)
            col = sand.lerp(col, smoothstep(0.2, 1.4, h))
            var rt := 1.0 - smoothstep(0.68, 0.86, nrm.y)
            col = col.lerp(rock, rt)
            cols.append(col)

    for j in SEGS:
        for i in SEGS:
            var a := j * n + i
            var b := a + 1
            var c := a + n
            var d := c + 1
            idx.append(a)
            idx.append(b)
            idx.append(c)
            idx.append(b)
            idx.append(d)
            idx.append(c)

    var arrays := []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = verts
    arrays[Mesh.ARRAY_NORMAL] = norms
    arrays[Mesh.ARRAY_COLOR] = cols
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_INDEX] = idx

    var am := ArrayMesh.new()
    am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.roughness = 1.0
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    am.surface_set_material(0, mat)

    var mi := MeshInstance3D.new()
    mi.mesh = am
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    mi.create_trimesh_collision()
    for ch in mi.get_children():
        if ch is StaticBody3D:
            ch.add_to_group("ground")
