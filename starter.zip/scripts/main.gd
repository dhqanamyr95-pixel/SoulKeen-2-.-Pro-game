extends Node

const MenuScript = preload("res://scripts/menu.gd")
const WorldScript = preload("res://scripts/world.gd")

var current: Node = null


func _ready() -> void:
    Engine.max_fps = 60
    _show_menu()


func _clear() -> void:
    if current != null:
        current.queue_free()
        current = null


func _show_menu() -> void:
    _clear()
    var menu = MenuScript.new()
    menu.map_chosen.connect(_start_world)
    current = menu
    add_child(menu)


func _start_world(map_id: String) -> void:
    _clear()
    var world = WorldScript.new()
    world.map_id = map_id
    world.exit_requested.connect(_show_menu)
    current = world
    add_child(world)
